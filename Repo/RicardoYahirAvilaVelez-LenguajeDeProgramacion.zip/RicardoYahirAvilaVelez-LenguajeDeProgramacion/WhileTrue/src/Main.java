public class Main {
    public static void main(String[] args) {
        int j = 0;
        while(true){
            j ++;
            System.out.println(j);
        }
    }
}